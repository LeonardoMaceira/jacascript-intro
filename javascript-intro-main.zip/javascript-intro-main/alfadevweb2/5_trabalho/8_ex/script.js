for (x=0; x <= 50; x++){
   if((x % 2) == 0){
      console.log(x + ' é um numer par ');
   }else{
      console.log(x + ' é um  num impar ');
   }
}