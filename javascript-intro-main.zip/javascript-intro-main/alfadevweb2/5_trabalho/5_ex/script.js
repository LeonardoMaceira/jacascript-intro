cnh = true; 
idade = 8;
if(idade >= 18 && cnh == true){
    console.log("Pode dirigir");
}else if(idade >= 18 || cnh == false){
    console.logo("Você não pode dirigir")
}