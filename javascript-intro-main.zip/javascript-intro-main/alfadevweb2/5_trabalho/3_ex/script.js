nome = "Jão";
idade = 18;
homen = true;
console.log(typeof(nome));
console.log(typeof(idade));
console.log(typeof(homen));