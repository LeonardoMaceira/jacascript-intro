
for (let x = 200; x>=200; index--) {
   console.log(x);
}