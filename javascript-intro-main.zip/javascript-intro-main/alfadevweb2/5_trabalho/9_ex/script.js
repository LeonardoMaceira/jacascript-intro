divisao = 0;
numero = prompt("insira um número");
for (x = numero; x > 0; x--){
   if(numero % x == 0){
      divisao++;
   }
}
if(divisao == 2){
   console.log(divisao + " - O numero " + numero + " é primo");
}else{
   console.log(diviaso + " - O numero " + numero + " não é primo");
}