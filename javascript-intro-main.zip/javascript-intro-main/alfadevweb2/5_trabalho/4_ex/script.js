valocidade = 85;
if(velocidade > 10){
    console.log("Multado!");
}else{
    console.log("Você n foi multado");
}