const nome = "Denicleiton";

if(nome == "Denicleiton"){
    console.log('Bem vindo')
    alert("Seja bem vindo" + nome);
}
