//for (inicialização) (condição) (expressão final) 
for(i=0; i < 100; i = i + 2){
    console.log(`A soma de i com 2 é  ${ i }`);
}