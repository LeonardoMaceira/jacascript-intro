nome = "Jefin";
switch(nome){
    case "Daniel":
        console.log("Bem vindo Daniel");
        break;
        case"João":
            console.log("Bem vindo João");
        break;
        default:
        console.log("Nome não encontrado!")
}