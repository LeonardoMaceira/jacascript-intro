alert('Isso é uma mensagem para você!');

alert('Isso é uma mensagem para você!');