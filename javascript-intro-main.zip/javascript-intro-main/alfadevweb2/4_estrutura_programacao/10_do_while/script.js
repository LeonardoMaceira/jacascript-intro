x = -1;
do{
    console.log(x);
    x--;
}while(x >= 0);

console.log('--');
x=-1;
while(x >= 0){
    console.log(x);
    x--;
}