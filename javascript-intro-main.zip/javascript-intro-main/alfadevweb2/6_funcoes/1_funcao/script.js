//declarando funcao
function imprimirConsole(){

    console.log("Olá mundo");  
}
//chmando a funcao
imprimirConsole();
                          //parametro
function imprimirNumero(num){
    console.log("O número é: " + num);
}
imprimirNumero(2);
imprimirNumero(5);