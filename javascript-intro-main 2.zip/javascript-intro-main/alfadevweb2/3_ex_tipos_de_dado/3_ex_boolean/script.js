/*Escreva três comparações com boolean;
-Uma com maior
- Menor ou igual 
- Diferente;
*/
console.log(9>8);
console.log(2<=1);
console.log(2!=3);

console.log(typeof(2!=3));