/*
Escreva três comparações 
com operadores lógicos;
Com and, 
or e 
not;
*/
console.log(9>8 && 19==9);
console.log(9>8 || 19==9);
console.log(!(9>8 || 19==9));
