/*
Faça uma operação que 
emita NaN no console 
do navegador;
*/
console.log(9 * 'a');