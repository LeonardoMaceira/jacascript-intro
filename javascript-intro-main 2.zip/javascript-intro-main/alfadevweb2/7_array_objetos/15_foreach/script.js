nome = ['Biruleite', 'pixuruca', 'Josemaria', 'Mariajose'];

nome.forEach(x => {
    console.log('bom estudos' + x)
});