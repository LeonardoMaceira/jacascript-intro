//for (inicialização); (condicao)
nomes = ['bil', 'mike', 'rick'];

for (let i = 0; i < nomes.length; i++) {
    console.log(nomes[i]);
    
}