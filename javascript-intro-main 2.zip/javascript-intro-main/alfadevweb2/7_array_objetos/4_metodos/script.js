marca = "nike";

console.log(marca.toUppercase());
//maiusculo

marca2 = marca.toUppercase();

console.log(marca2.toLowerCase());
//minusculo

