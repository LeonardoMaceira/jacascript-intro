carro = {
    portas: 2,
    portamalas: "200L",
    motor: '2.0 turbo'
}
adicionais = {
    tetosolar: true,
    arcodicionado: true
}

console.log(carro);
Object.assign(carro, adicionais);
console.log(carro);