num = [5,6,7,8,4];

console.log(num.indexOf(8));
console.log(num.indexOf(4));
console.log(num.indexOf(3));