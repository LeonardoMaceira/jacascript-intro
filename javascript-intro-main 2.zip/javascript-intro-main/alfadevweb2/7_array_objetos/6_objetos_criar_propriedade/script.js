pessoa = {
    name: "afonso", idade: 12, profissao: "aprendiz",

}
console.log(pessoa.name);
delete pessoa.nome;
console.log(pessoa.nome);
console.log(pessoa);
pessoa.casado = false;
console.log(pessoa.casado);
console.log(pessoa);