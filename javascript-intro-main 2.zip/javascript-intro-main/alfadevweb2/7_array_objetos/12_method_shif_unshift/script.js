//adiciona e remove o inicio

nomes = ['Juvilino', 'Billyson', 'denycride'];

console.log(nomes.shifr());

console.log(nomes);

nomes.unshift('izabel', 'rip');

console.log(nomes); 