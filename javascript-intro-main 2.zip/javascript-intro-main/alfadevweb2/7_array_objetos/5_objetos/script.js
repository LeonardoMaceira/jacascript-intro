//objetos
cachorro = {
    
    //propridades
    cor: "caramelo", patas: 4, nome: 'Cavalo',

    //metodo
    latir: function(){
        console.log('miau');
    }
}
console.log(cachorro.cor);
console.log(cachorro.nome);
console.log(cachorro.patas);

cachorro.latir();