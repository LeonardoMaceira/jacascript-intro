obj = {
    'chave':1,
    'chave':2,
    'chave':3,
}
console.log(obj);

console.log(Object.keys(obj));