nomes = [ 'bil', 'jack', 'rick'];

elementoRemovido = nomes.pop();

console.log(elementoRemovido);

console.log(nomes);

nomes.push('tiao');

console.log(nomes);