pessoa = {
    nome: 'juviliane'
}
pessoa2 = pessoa;
console.log(pessoa.nome);

pessoa2.nome='ju';

console.log(pessoa.nome);
console.log(pessoa2.nome);

pessoa.nome='joao';

console.log(pessoa.nome);
console.log(pessoa2.nome);

pessoa3={
    nome:'jorge'
}

pessoa3 = pessoa;

console.log(pessoa3.nome);